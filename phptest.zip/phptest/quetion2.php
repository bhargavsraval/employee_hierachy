<?php
require 'config.php';

$code = $_REQUEST['code'];
try{
    $emp_detail = $conn->prepare("SELECT u.id,u.role
    FROM users as u
    join user_client_adopted as uca on  uca.user_id = u.id
    WHERE uca.code = ".$code);

    $emp_detail->execute(); 
    $emp_detail = $emp_detail->fetchAll();
} catch (Exception $ex) {
    exit("Enter Valid code");
}


if(count($emp_detail) > 0) {
    for($i=$emp_detail[0]['role'];$i>=3;$i--)
    {            
           $role = $emp_detail[0]['role'] == "5" ? "Adoption by FO:" : ($emp_detail[0]['role'] == "4" ? "Adoption by ABM:" : "Adoption by SM:");  
           echo  $role.count($emp_detail)."<br/>";
           $emp_parent_detail = $conn->prepare("SELECT u.code FROM user_relation ur JOIN users u ON u.id = ur.parent_id WHERE ur.user_id = ".$emp_detail[0]['id']);               
           $emp_parent_detail->execute(); 
           $emp_parent_detail = $emp_parent_detail->fetchAll(); 
           getUseradoptionDetail($emp_parent_detail[0]['code']);
           exit();
    }
}else{
    echo "No data found";
}

function getUseradoptionDetail($code)
{                              
    global $conn;
    $emp_detail = $conn->prepare("SELECT u.id,u.role
                    FROM users as u
                    join user_client_adopted as uca on  uca.user_id = u.id
                    WHERE uca.code = ".$code);

                    $emp_detail->execute(); 
                    $emp_detail = $emp_detail->fetchAll();
    
    
    if(count($emp_detail) > 0) {
        for($i=$emp_detail[0]['role'];$i>=3;$i--)
        {             
           $role = $emp_detail[0]['role'] == "4" ? "Adoption by ABM:" : "Adoption by SM:";
           echo  $role.count($emp_detail)."<br/>";
           $emp_parent_detail = $conn->prepare("SELECT u.code FROM user_relation ur JOIN users u ON u.id = ur.parent_id WHERE ur.user_id = ".$emp_detail[0]['id']);           
           $emp_parent_detail->execute();
           $emp_parent_detail = $emp_parent_detail->fetchAll();
           getUseradoptionDetail($emp_parent_detail[0]['code']);          
           exit();
        }
    }        
}



?>